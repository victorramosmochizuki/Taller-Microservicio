package payment.saga.order.enums;

public enum PaymentStatus {

    APPROVED,
    DECLINED

}
