package payment.saga.order.model;

public interface Event {

    String getEvent();
}
