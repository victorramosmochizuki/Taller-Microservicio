package payment.saga.order.enums;

public enum OrderStatus {

    CREATED,
    COMPLETED,
    FAILED

}
