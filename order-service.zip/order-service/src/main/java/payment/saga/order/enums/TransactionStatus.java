package payment.saga.order.enums;

public enum TransactionStatus {

    SUCCESSFUL,
    UNSUCCESSFUL

}
