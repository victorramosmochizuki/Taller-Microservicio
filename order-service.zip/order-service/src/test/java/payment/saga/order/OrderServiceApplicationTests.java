package payment.saga.order;

class OrderServiceApplicationTests {


	void contextLoads() {
	}

}
