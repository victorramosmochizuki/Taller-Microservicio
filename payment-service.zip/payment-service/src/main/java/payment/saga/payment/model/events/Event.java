package payment.saga.payment.model.events;

public interface Event {

    String getEvent();
}
