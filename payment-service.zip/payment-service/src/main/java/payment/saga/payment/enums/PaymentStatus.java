package payment.saga.payment.enums;

public enum PaymentStatus {

    APPROVED,
    DECLINED

}
