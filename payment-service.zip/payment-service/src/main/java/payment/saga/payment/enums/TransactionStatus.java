package payment.saga.payment.enums;

public enum TransactionStatus {

    SUCCESSFUL,
    UNSUCCESSFUL

}
