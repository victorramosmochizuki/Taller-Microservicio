package payment.saga.payment;

class PaymentServiceApplicationTests {


    void contextLoads() {
    }

}
